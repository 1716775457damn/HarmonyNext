interface Index_Params {
    message?: string;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('学鸿蒙来黑马', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/21-\u6848\u4F8B-QQ\u97F3\u4E50.ets(6:5)");
            Column.width('100%');
            Column.padding(30);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/21-\u6848\u4F8B-QQ\u97F3\u4E50.ets(7:7)");
            Image.width(100);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('大王叫我来巡山');
            Text.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/21-\u6848\u4F8B-QQ\u97F3\u4E50.ets(9:7)");
            Text.fontWeight(700);
            Text.margin({
                top: 10,
                bottom: 40
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('QQ登录');
            Button.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/21-\u6848\u4F8B-QQ\u97F3\u4E50.ets(16:7)");
            Button.width('100%');
            Button.margin({
                bottom: 10
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('微信登录');
            Button.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/21-\u6848\u4F8B-QQ\u97F3\u4E50.ets(21:7)");
            Button.width('100%');
            Button.backgroundColor('#ddd');
            Button.fontColor('#000');
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.myfirst", moduleName: "entry", pagePath: "\u968F\u5802\u4EE3\u7801/21-\u6848\u4F8B-QQ\u97F3\u4E50" });
