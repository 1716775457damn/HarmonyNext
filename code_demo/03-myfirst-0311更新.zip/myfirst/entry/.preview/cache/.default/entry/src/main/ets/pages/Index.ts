interface Index_Params {
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 思路：
            // 1. 整体Stack布局 + 底部的tab
            // 2. 主体区域的架子：头部 + 主体页面 （层叠关系、主体页面可滚动）
            //    Column/Row，默认不具备可滚动的效果 → Scroll
            // 3. Head头部区域：左 中 右 三部分
            // 4. Top快捷按钮区域：Row里面4个Column （layoutWeight）
            // 5. Nav导航区域：一个列，3行，每行5列
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(12:5)");
            // 思路：
            // 1. 整体Stack布局 + 底部的tab
            // 2. 主体区域的架子：头部 + 主体页面 （层叠关系、主体页面可滚动）
            //    Column/Row，默认不具备可滚动的效果 → Scroll
            // 3. Head头部区域：左 中 右 三部分
            // 4. Top快捷按钮区域：Row里面4个Column （layoutWeight）
            // 5. Nav导航区域：一个列，3行，每行5列
            Stack.width('100%');
            // 思路：
            // 1. 整体Stack布局 + 底部的tab
            // 2. 主体区域的架子：头部 + 主体页面 （层叠关系、主体页面可滚动）
            //    Column/Row，默认不具备可滚动的效果 → Scroll
            // 3. Head头部区域：左 中 右 三部分
            // 4. Top快捷按钮区域：Row里面4个Column （layoutWeight）
            // 5. Nav导航区域：一个列，3行，每行5列
            Stack.height('100%');
            // 思路：
            // 1. 整体Stack布局 + 底部的tab
            // 2. 主体区域的架子：头部 + 主体页面 （层叠关系、主体页面可滚动）
            //    Column/Row，默认不具备可滚动的效果 → Scroll
            // 3. Head头部区域：左 中 右 三部分
            // 4. Top快捷按钮区域：Row里面4个Column （layoutWeight）
            // 5. Nav导航区域：一个列，3行，每行5列
            Stack.backgroundColor('#5b73de');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 主体展示区
            Stack.create({ alignContent: Alignment.Top });
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(14:7)");
            // 主体展示区
            Stack.width('100%');
            // 主体展示区
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 头部
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(16:9)");
            // 头部
            Row.padding({ left: 10, right: 10 });
            // 头部
            Row.width('100%');
            // 头部
            Row.height(60);
            // 头部
            Row.backgroundColor('#5b73de');
            // 头部
            Row.zIndex(666);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 左边
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(18:11)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('北京');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(19:13)");
            Text.fontSize(18);
            Text.fontColor('#fff');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('晴 2°C');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(20:13)");
            Text.fontSize(12);
            Text.fontColor('#fff');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777272, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(21:13)");
            Image.position({
                x: 40,
                y: 0
            });
            Image.width(12);
            Image.fillColor('#fff');
        }, Image);
        // 左边
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 中间
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(30:11)");
            // 中间
            Row.height(32);
            // 中间
            Row.layoutWeight(1);
            // 中间
            Row.backgroundColor('#fff');
            // 中间
            Row.borderRadius(5);
            // 中间
            Row.margin({ left: 25, right: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777277, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(31:13)");
            Image.width(20);
            Image.fillColor('#666');
            Image.margin({ left: 5, right: 5 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('北京交通一卡通');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(35:13)");
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('搜索');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(37:13)");
            Text.width(55);
            Text.fontColor('#5b73de');
            Text.fontWeight(700);
            Text.textAlign(TextAlign.Center);
            Text.border({
                width: { left: 1 },
                color: '#ccc'
            });
        }, Text);
        Text.pop();
        // 中间
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 右边
            Image.create({ "id": 16777291, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(54:11)");
            // 右边
            Image.width(30);
            // 右边
            Image.fillColor('#fff');
        }, Image);
        // 头部
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 主体页面
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Index.ets(65:9)");
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(66:11)");
            Column.width('100%');
            Column.padding({ top: 60, bottom: 60 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Top快捷按钮区域
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(68:13)");
            // Top快捷按钮区域
            Row.backgroundColor('#5b73de');
            // Top快捷按钮区域
            Row.padding({ top: 5, bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(69:15)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777266, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(70:17)");
            Image.width(36);
            Image.fillColor('#fff');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('扫一扫');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(73:17)");
            Text.fontColor('#fff');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(78:15)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777280, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(79:17)");
            Image.width(36);
            Image.fillColor('#fff');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('收付款');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(82:17)");
            Text.fontColor('#fff');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(87:15)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777281, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(88:17)");
            Image.width(36);
            Image.fillColor('#fff');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('出行');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(91:17)");
            Text.fontColor('#fff');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(96:15)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777263, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(97:17)");
            Image.width(36);
            Image.fillColor('#fff');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('卡包');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(100:17)");
            Text.fontColor('#fff');
        }, Text);
        Text.pop();
        Column.pop();
        // Top快捷按钮区域
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 主体区（背景色 #f6f6f6）
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(109:13)");
            // 主体区（背景色 #f6f6f6）
            Column.width('100%');
            // 主体区（背景色 #f6f6f6）
            Column.backgroundColor('#fff');
            // 主体区（背景色 #f6f6f6）
            Column.borderRadius({
                topLeft: 20,
                topRight: 20
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 导航区域
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(111:15)");
            // 导航区域
            Column.padding(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(112:17)");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(113:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777283, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(114:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('滴滴出行');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(116:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(121:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777279, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(122:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('生活缴费');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(124:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(129:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777259, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(130:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('股票');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(132:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(137:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777284, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(138:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('蚂蚁森林');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(140:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(145:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777282, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(146:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('手机充值');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(148:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(155:17)");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(156:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777273, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(157:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('余额宝');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(159:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(164:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777268, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(165:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('花呗');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(167:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(172:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777271, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(173:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('飞猪旅行');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(175:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(180:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777275, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(181:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('淘票票');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(183:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(188:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777260, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(189:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('饿了么');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(191:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(198:17)");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(199:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777261, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(200:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('读书听书');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(202:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(207:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777267, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(208:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('基金');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(210:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(215:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777289, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(216:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('直播广场');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(218:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(223:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777270, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(224:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('医疗健康');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(226:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(231:19)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777269, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(232:21)");
            Image.width(28);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('更多');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(234:21)");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        // 导航区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 产品区
            Row.create({ space: 5 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(244:15)");
            // 产品区
            Row.padding(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777285, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(245:17)");
            Image.layoutWeight(1);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777276, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(247:17)");
            Image.layoutWeight(1);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777265, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(249:17)");
            Image.layoutWeight(1);
        }, Image);
        // 产品区
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(254:15)");
            Column.padding(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777287, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(255:17)");
            Image.width('100%');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777286, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(257:17)");
            Image.width('100%');
        }, Image);
        Column.pop();
        // 主体区（背景色 #f6f6f6）
        Column.pop();
        Column.pop();
        // 主体页面
        Scroll.pop();
        // 主体展示区
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 底部Tab导航区
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(278:7)");
            // 底部Tab导航区
            Row.width('100%');
            // 底部Tab导航区
            Row.height(60);
            // 底部Tab导航区
            Row.backgroundColor('#fbfcfe');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(279:9)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777290, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(280:11)");
            Image.width(35);
        }, Image);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(285:9)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777288, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(286:11)");
            Image.width(28);
            Image.margin({ bottom: 2 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('理财');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(288:11)");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(293:9)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777274, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(294:11)");
            Image.width(28);
            Image.margin({ bottom: 2 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('生活');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(296:11)");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(301:9)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777262, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(302:11)");
            Image.width(28);
            Image.margin({ bottom: 2 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('消息');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(304:11)");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(309:9)");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777278, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(310:11)");
            Image.width(28);
            Image.margin({ bottom: 2 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(312:11)");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Column.pop();
        // 底部Tab导航区
        Row.pop();
        // 思路：
        // 1. 整体Stack布局 + 底部的tab
        // 2. 主体区域的架子：头部 + 主体页面 （层叠关系、主体页面可滚动）
        //    Column/Row，默认不具备可滚动的效果 → Scroll
        // 3. Head头部区域：左 中 右 三部分
        // 4. Top快捷按钮区域：Row里面4个Column （layoutWeight）
        // 5. Nav导航区域：一个列，3行，每行5列
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.myfirst", moduleName: "entry", pagePath: "pages/Index" });
