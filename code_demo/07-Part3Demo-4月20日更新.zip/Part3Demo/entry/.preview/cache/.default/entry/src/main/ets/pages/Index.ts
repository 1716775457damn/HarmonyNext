interface Index_Params {
    selectedIndex?: number;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__selectedIndex = new ObservedPropertySimplePU(0, this, "selectedIndex");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.selectedIndex !== undefined) {
            this.selectedIndex = params.selectedIndex;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectedIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 准备状态, 存储激活的索引
    private __selectedIndex: ObservedPropertySimplePU<number>;
    get selectedIndex() {
        return this.__selectedIndex.get();
    }
    set selectedIndex(newValue: number) {
        this.__selectedIndex.set(newValue);
    }
    myBuilder(itemIndex: number, title: string, img: ResourceStr, selImg: ResourceStr, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 如果激活的是自己, 图片/文本 都需要调整样式 → 需要区分不同的 tabBar
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(10:5)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(itemIndex == this.selectedIndex ? selImg : img);
            Image.debugLine("entry/src/main/ets/pages/Index.ets(11:7)");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(13:7)");
            Text.fontColor(itemIndex == this.selectedIndex ? Color.Red : Color.Black);
        }, Text);
        Text.pop();
        // 如果激活的是自己, 图片/文本 都需要调整样式 → 需要区分不同的 tabBar
        Column.pop();
    }
    centerBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777237, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(20:5)");
            Image.width(40);
            Image.margin({ bottom: 10 });
        }, Image);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(26:5)");
            Tabs.onChange((index: number) => {
                // console.log('激活的索引', index)
                this.selectedIndex = index;
            });
            Tabs.animationDuration(0);
            Tabs.scrollable(false);
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('首页内容');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(28:9)");
                }, Text);
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.myBuilder.call(this, 0, '首页', { "id": 16777250, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" }, { "id": 16777241, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(27:7)");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('分类内容');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(33:9)");
                }, Text);
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.myBuilder.call(this, 1, '分类', { "id": 16777252, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" }, { "id": 16777253, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(32:7)");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('活动内容');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(39:9)");
                }, Text);
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.centerBuilder.call(this);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(38:7)");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('购物车内容');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(44:9)");
                }, Text);
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.myBuilder.call(this, 3, '购物车', { "id": 16777243, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" }, { "id": 16777242, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(43:7)");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('我的内容');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(49:9)");
                }, Text);
                Text.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.myBuilder.call(this, 4, '我的', { "id": 16777244, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" }, { "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(48:7)");
        }, TabContent);
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.part3demo", moduleName: "entry", pagePath: "pages/Index" });
