interface Index3_Params {
    // 1. 创建scroll实例对象
    myScroll?: Scroller;
    yOffset?: number;
}
class Index3 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.myScroll = new Scroller();
        this.__yOffset = new ObservedPropertySimplePU(0 // 实时保存y轴滚动的距离
        , this, "yOffset");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index3_Params) {
        if (params.myScroll !== undefined) {
            this.myScroll = params.myScroll;
        }
        if (params.yOffset !== undefined) {
            this.yOffset = params.yOffset;
        }
    }
    updateStateVars(params: Index3_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__yOffset.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__yOffset.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 1. 创建scroll实例对象
    private myScroll: Scroller;
    private __yOffset: ObservedPropertySimplePU<number>; // 实时保存y轴滚动的距离
    get yOffset() {
        return this.__yOffset.get();
    }
    set yOffset(newValue: number) {
        this.__yOffset.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(10:5)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.BottomEnd });
            Stack.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(11:7)");
            Stack.layoutWeight(1);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部滚动区域
            // 2. 和Scroll容器绑定
            Scroll.create(this.myScroll);
            Scroll.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(14:9)");
            // 顶部滚动区域
            // 2. 和Scroll容器绑定
            Scroll.scrollBar(BarState.Off);
            // 顶部滚动区域
            // 2. 和Scroll容器绑定
            Scroll.width('100%');
            // 顶部滚动区域
            // 2. 和Scroll容器绑定
            Scroll.backgroundColor(Color.Orange);
            // 顶部滚动区域
            // 2. 和Scroll容器绑定
            Scroll.onScroll(() => {
                this.yOffset = this.myScroll.currentOffset().yOffset;
            });
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(15:11)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777248, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(16:13)");
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777245, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(17:13)");
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777251, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(18:13)");
        }, Image);
        Column.pop();
        // 顶部滚动区域
        // 2. 和Scroll容器绑定
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 有时显示, 有时隐藏 → 条件渲染
            if (this.yOffset > 400) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777246, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(30:11)");
                        Image.width(40);
                        Image.backgroundColor(Color.White);
                        Image.borderRadius(20);
                        Image.padding(5);
                        Image.offset({ x: -20, y: -20 });
                        Image.onClick(() => {
                            // 3. 调用实例方法完成回到顶部的功能
                            this.myScroll.scrollEdge(Edge.Top);
                        });
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 底部 tabbar 图片(后面会学)
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.part3demo", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210.ets(45:7)");
            // 底部 tabbar 图片(后面会学)
            Image.width('100%');
        }, Image);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index3";
    }
}
registerNamedRoute(() => new Index3(undefined, {}), "", { bundleName: "com.example.part3demo", moduleName: "entry", pagePath: "\u968F\u5802\u4EE3\u7801/17-\u4EAC\u4E1C\u5B9E\u4F8B-\u529F\u80FD\u5B8C\u6210" });
