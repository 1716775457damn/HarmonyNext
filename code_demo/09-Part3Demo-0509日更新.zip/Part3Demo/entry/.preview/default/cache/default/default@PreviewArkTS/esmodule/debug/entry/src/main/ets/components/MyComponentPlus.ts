interface MyComponentPlus_Params {
    count?: number;
}
export class MyComponentPlus extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__count = new ObservedPropertySimplePU(1, this, "count");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: MyComponentPlus_Params) {
        if (params.count !== undefined) {
            this.count = params.count;
        }
    }
    updateStateVars(params: MyComponentPlus_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__count.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__count.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __count: ObservedPropertySimplePU<number>;
    get count() {
        return this.__count.get();
    }
    set count(newValue: number) {
        this.__count.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/MyComponentPlus.ets(9:5)");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.padding(10);
            Row.border({ width: 1 });
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('自定义组件' + this.count);
            Text.debugLine("entry/src/main/ets/components/MyComponentPlus.ets(10:7)");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('按钮');
            Button.debugLine("entry/src/main/ets/components/MyComponentPlus.ets(11:7)");
            Button.onClick(() => {
                this.count++;
            });
        }, Button);
        Button.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "MyComponentPlus", new MyComponentPlus(undefined, {}));
    previewComponent();
}
else {
}
