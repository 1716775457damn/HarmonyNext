const fn = () => {
    console.log('你好');
};
export default fn;
