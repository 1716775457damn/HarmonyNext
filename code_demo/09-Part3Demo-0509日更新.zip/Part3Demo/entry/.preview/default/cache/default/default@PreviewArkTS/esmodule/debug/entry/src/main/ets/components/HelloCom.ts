interface HelloCom_Params {
}
export class HelloCom extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: HelloCom_Params) {
    }
    updateStateVars(params: HelloCom_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/HelloCom.ets(5:5)");
            Row.width(200);
            Row.height(50);
            Row.backgroundColor(Color.Orange);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('自定义组件');
            Text.debugLine("entry/src/main/ets/components/HelloCom.ets(6:7)");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('按钮');
            Button.debugLine("entry/src/main/ets/components/HelloCom.ets(7:7)");
        }, Button);
        Button.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "HelloCom", new HelloCom(undefined, {}));
    previewComponent();
}
else {
}
