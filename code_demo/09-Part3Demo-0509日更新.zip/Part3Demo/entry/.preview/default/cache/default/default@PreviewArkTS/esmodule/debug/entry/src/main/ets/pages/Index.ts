interface Index_Params {
    num1?: number;
    num2?: number;
}
interface NumberCount_Params {
    num?: number;
    subFn?;
    addFn?;
}
class NumberCount extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__num = new SynchedPropertySimpleOneWayPU(params.num, this, "num");
        this.subFn = () => { };
        this.addFn = () => { };
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: NumberCount_Params) {
        if (params.num === undefined) {
            this.__num.set(1);
        }
        if (params.subFn !== undefined) {
            this.subFn = params.subFn;
        }
        if (params.addFn !== undefined) {
            this.addFn = params.addFn;
        }
    }
    updateStateVars(params: NumberCount_Params) {
        this.__num.reset(params.num);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__num.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__num.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __num: SynchedPropertySimpleOneWayPU<number>;
    get num() {
        return this.__num.get();
    }
    set num(newValue: number) {
        this.__num.set(newValue);
    }
    private subFn;
    private addFn;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 数字框组件
            Row.create({ space: 5 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(8:5)");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('-');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(9:7)");
            Button.onClick(() => {
                this.subFn();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.num.toString());
            Text.debugLine("entry/src/main/ets/pages/Index.ets(12:7)");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('+');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(13:7)");
            Button.onClick(() => {
                this.addFn();
            });
        }, Button);
        Button.pop();
        // 数字框组件
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__num1 = new ObservedPropertySimplePU(5, this, "num1");
        this.__num2 = new ObservedPropertySimplePU(3, this, "num2");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.num1 !== undefined) {
            this.num1 = params.num1;
        }
        if (params.num2 !== undefined) {
            this.num2 = params.num2;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__num1.purgeDependencyOnElmtId(rmElmtId);
        this.__num2.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__num1.aboutToBeDeleted();
        this.__num2.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __num1: ObservedPropertySimplePU<number>;
    get num1() {
        return this.__num1.get();
    }
    set num1(newValue: number) {
        this.__num1.set(newValue);
    }
    private __num2: ObservedPropertySimplePU<number>;
    get num2() {
        return this.__num2.get();
    }
    set num2(newValue: number) {
        this.__num2.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(27:5)");
            Column.padding(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(28:7)");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('茄子');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(29:9)");
        }, Text);
        Text.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NumberCount(this, {
                        num: this.num1,
                        addFn: () => this.num1++,
                        subFn: () => this.num1--
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 30 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            num: this.num1,
                            addFn: () => this.num1++,
                            subFn: () => this.num1--
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        num: this.num1
                    });
                }
            }, { name: "NumberCount" });
        }
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(36:7)");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('香蕉');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(37:9)");
        }, Text);
        Text.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NumberCount(this, {
                        num: this.num2,
                        addFn: () => this.num2++,
                        subFn: () => this.num2--
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 38 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            num: this.num2,
                            addFn: () => this.num2++,
                            subFn: () => this.num2--
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        num: this.num2
                    });
                }
            }, { name: "NumberCount" });
        }
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.part3demo", moduleName: "entry", pagePath: "pages/Index" });
